/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lighting.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.inject.Inject;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import lighting.ejbs.UserAuthentication;
import lighting.entities.UserEntity;
import lighting.entity.ejbs.UserEntityFacadeLocal;
import lighting.model.beans.ShoppingCart;



@WebServlet(name = "MyAccountServlet", urlPatterns = {"/myaccount"})
public class MyAccountServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    
    @Inject
    private ShoppingCart cart;
    @EJB
    private UserEntityFacadeLocal uefl;
    @EJB
    private UserAuthentication ua;
    private final String changepassword = "changepassword";
    private final String cancel = "cancel";
    private final String change = "change";
    private final String currentpassword = "currentpassword";
    private final String newpassword = "newpassword";
    private final String reconfirm = "reconfirm";
    private final String password = "/changepassword.jsp";
    private final String account = "/account.jsp";
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        String contextPath = request.getContextPath();
        
        String cpd = request.getParameter(changepassword);
        String can = request.getParameter(cancel);
        String cha = request.getParameter(change);
        String cur = request.getParameter(currentpassword);
        String npd = request.getParameter(newpassword);
        String rec = request.getParameter(reconfirm);
        
        if(cpd != null){
           response.sendRedirect(contextPath + password);
        }
        
        if(can != null){
           response.sendRedirect(contextPath + account); 
        }
        
        if(cha != null){
            //This is an action to change the password
            
            //all input password cannot be blank or empty
            if(cur.trim().isEmpty() || cur == null){
                request.setAttribute("curemptyMsg", "Old Password cannot be empty");
                RequestDispatcher rd = request.getRequestDispatcher(password);
                rd.forward(request, response);
            }
            if(npd.trim().isEmpty() || npd == null){
                request.setAttribute("newemptyMsg", "New Password cannot be empty");
                RequestDispatcher rd = request.getRequestDispatcher(password);
                rd.forward(request, response);
            }
            if(rec.trim().isEmpty() || rec == null){
                request.setAttribute("recemptyMsg", "Confirm New Password cannot be empty");
                RequestDispatcher rd = request.getRequestDispatcher(password);
                rd.forward(request, response);
            }
            if(npd.length() <= 3){
                request.setAttribute("newlessthan4Msg", "New Password: size must be between 4 and 255");
                RequestDispatcher rd = request.getRequestDispatcher(password);
                rd.forward(request, response);
            }
            if(rec.length() <= 3){
                request.setAttribute("reclessthan4Msg", "Confirm New Password: size must be between 4 and 255");
                RequestDispatcher rd = request.getRequestDispatcher(password);
                rd.forward(request, response);
            }
            //verify current password
            if(ua.isPasswordVerified(cart.getUsername(), cur)){
               
                if(npd.equals(cur)){
                    //new password cannot be current password
                    request.setAttribute("nochangeMsg", "Your new password is same as your old passowrd");
                    RequestDispatcher rd = request.getRequestDispatcher(password);
                    rd.forward(request, response);
                }else if(!npd.equals(rec)){
                    //new password does not match with re-confirm password
                    request.setAttribute("notmatchMsg", "New Password does not match with Confirm New Password");
                    RequestDispatcher rd = request.getRequestDispatcher(password);
                    rd.forward(request, response);
                }else {
                    //change to new password
                    UserEntity ue = new UserEntity();
                    ue = uefl.find(cart.getUsername());
                    ue.setPassword(npd);
                    uefl.edit(ue);
                    request.setAttribute("changedMsg", "Your password is changed successfully!");
                    RequestDispatcher rd = request.getRequestDispatcher(account);
                    rd.forward(request, response);
                }    
            }else{
                //current password is incorrect
                request.setAttribute("invalidMsg", "Invalid password");
                RequestDispatcher rd = request.getRequestDispatcher(password);
                rd.forward(request, response);
            }
        }
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
