/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lighting.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import lighting.entities.ProductEntity;
import lighting.entity.ejbs.ProductEntityFacadeLocal;
import lighting.model.beans.ShoppingCart;
import lighting.models.Purchase;


@WebServlet(name = "ShoppingCart", urlPatterns = {"/shoppingcart"})
public class ShoppingCartServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    
    @EJB
    private ProductEntityFacadeLocal pefl;
    @Inject
    private ShoppingCart cart;
    private final String addToCart = "add_to_cart";
    private final String increase = "increase";
    private final String decrease = "decrease";
    private final String remove = "remove";
    private final String id = "id";
    private final String shoppingCart = "/shoppingcart.jsp";
    private final String index = "/catalog.jsp";
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        //get the parameter from view in order to determine which action should be done
        String add = request.getParameter(addToCart);
        String inc = request.getParameter(increase);
        String dec = request.getParameter(decrease);
        String rem = request.getParameter(remove);
        
        String contextPath = request.getContextPath();
        
        
        if(add != null) {
            /*
            This is an action for adding purchase to the shoppin cart
            */

            //get the product ID which is selected by the user
            String a = request.getParameter(id);
            int productId = Integer.parseInt(a);
            
            //find the product with the give product ID from the database
            ProductEntity pe = new ProductEntity();
            pe = pefl.find(productId);
        
            //get the product name from the database
            String name =  pe.getName();

        
            //get the product price  from the database
            float price = pe.getPrice();
 
                    
            //get the product image link from the database
            String imageLink = pe.getImageLink();

            //add the product to the cart if the product is not in the shopping cart;
            Purchase purchase = new Purchase(productId);
            purchase.setName(name);
            purchase.setPrice(price);
            purchase.setImageLink(imageLink);
            purchase.setSubTotal();
            cart.addPurchase(purchase);
            
            response.sendRedirect(contextPath + index);
            
        }else if(inc != null) {
            /*
            This is an action to increase quantity 
            */
            
            //get the product ID which is selected by the user
            String a = request.getParameter("id");
            int productId = Integer.parseInt(a);
        
            //increase quantity by 1
            cart.increaseQuantity(productId);
            
            //update the subtotal
            cart.updateSubTotal(productId);
            
            response.sendRedirect(contextPath + shoppingCart);
            
        }else if(dec != null){
            /*
            This is an action to decrease quantity
            */
            
            //get the product ID which is selected by the user
            String a = request.getParameter(id);
            int productId = Integer.parseInt(a);
        
            //decrease quantity by 1
            cart.decreaseQuantity(productId);
        
            //update the subtotal
            cart.updateSubTotal(productId);
            
            response.sendRedirect(contextPath + shoppingCart);
        
        }else if(rem != null){
            /*
            This is an action to remove item from the shopping cart
            */
            
            //get the product ID which is selected by the user
            String a = request.getParameter(id);
            int productId = Integer.parseInt(a);
        
            //remove item from the cart
            cart.removePurchasedItem(productId);
            
            response.sendRedirect(contextPath + shoppingCart);
        }
        
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
