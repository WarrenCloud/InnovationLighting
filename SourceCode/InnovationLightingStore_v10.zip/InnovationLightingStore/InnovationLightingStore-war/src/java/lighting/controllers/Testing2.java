/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lighting.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import lighting.entity.ejbs.UserEntityFacadeLocal;
import lighting.entities.UserEntity;

/**
 *
 * @author William
 */
@WebServlet(name = "Testing2", urlPatterns = {"/testing2"})
public class Testing2 extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    
    @EJB
    private UserEntityFacadeLocal uefl;
    
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        UserEntity ue1 = new UserEntity();
        ue1.setUsername("William");
        ue1.setPassword("1234");
        ue1.setEmail("wailim.tai1001@gmail.com");
        uefl.create(ue1);
        
        UserEntity ue2 = new UserEntity();
        ue2.setUsername("Warren");
        ue2.setPassword("1234");
        ue2.setEmail("warren@gmail.com");
        uefl.create(ue2);
        
        UserEntity ue3 = new UserEntity();
        ue3.setUsername("Allan");
        ue3.setPassword("1234");
        ue3.setEmail("allan@gmail.com");
        uefl.create(ue3);
        
        UserEntity ue4 = new UserEntity();
        ue4.setUsername("Issac");
        ue4.setPassword("1234");
        ue4.setEmail("issac@gmail.com");
        uefl.create(ue4);
        
        response.sendRedirect("index.jsp");
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
