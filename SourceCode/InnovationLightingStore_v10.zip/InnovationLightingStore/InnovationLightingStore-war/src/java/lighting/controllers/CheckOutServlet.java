/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lighting.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.time.LocalDate;
import javax.ejb.EJB;
import javax.inject.Inject;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import lighting.entity.ejbs.OrderEntityFacadeLocal;
import lighting.entity.ejbs.OrderItemEntityFacadeLocal;
import lighting.entities.OrderEntity;
import lighting.entities.OrderItemEntity;
import lighting.entities.UserEntity;
import lighting.entity.ejbs.UserEntityFacadeLocal;
import lighting.model.beans.ShoppingCart;
import lighting.models.ChargeMasterCard;
import lighting.models.Purchase;
import lighting.models.SendEmailViaGmail;

/**
 *
 * @author William
 */
@WebServlet(name = "CheckOut", urlPatterns = {"/checkout"})
public class CheckOutServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    
    @Inject
    private ShoppingCart cart;
    
    @EJB
    private UserEntityFacadeLocal uefl;
    
    @EJB
    private OrderEntityFacadeLocal oefl;
    
    @EJB
    private OrderItemEntityFacadeLocal orefl;
    
    private int orderId;
    private final String checkout = "checkout";
    private final String card = "card";
    private final String payment = "payment";
    private final String master = "master";
    private final String cancel = "cancel";
    private final String from = "innovationlighting.hk@gmail.com";
    private final String username = "innovationlighting.hk@gmail.com";
    private final String password = "COMP5322";
    private final String hkd = "HKD";   //Hong Kong currency
    private final String usd = "USD";   //Hong Kong currency
    private final String description = "Innovation Lighting Store";
    
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        String contextPath = request.getContextPath();
        
        //retreive customer username;
        String customer = cart.getUsername();
        
        //to determin which action should be done
        String che = request.getParameter(checkout);
        String car = request.getParameter(card);
        String pay = request.getParameter(payment);
        String mas = request.getParameter(master);
        String can = request.getParameter(cancel);

        //get the token for Master card payment
        String token = request.getParameter("simplifyToken");
        
        if (che != null){
            /*
            This is an action for checkout. If the user does not login, redirect
            to login.jsp. If the shopping cart is empty, redirect to catalog.jsp
            */
            
            if (cart.getUsername() == null){
                response.sendRedirect(contextPath + "/login.jsp");
            }else if(cart.isEmptyCart() == true){
                response.sendRedirect(contextPath + "/catalog.jsp");
            }else {
                RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/payment.jsp");
                rd.forward(request, response);
            }
        }else if(car != null){
            //retrive delivery and billing info and then go to payment_with_master_card jsp
           
            RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/payment_with_master_card.jsp");
            rd.forward(request, response);
            
        }else if (pay != null){
            
            //create a order ID and record the date and current status 
            OrderEntity oe = new OrderEntity();
            oe.setUsername(customer);
            oe.setOrderDate(Date.valueOf(LocalDate.now()));
            oe.setStatus("being_processed");
            oe.setPaymentMethod("cheque");
            oe.setPayment("unclear");
            oefl.create(oe);
        
            //after creating a order ID, retrieve the order ID from the database
            for(OrderEntity oee: oefl.findAll()){
                if(oee.getUsername().equals(customer)){
                   orderId = oee.getId();
                }
            }
            
            //create a order item ID for each purchased item and record related information 
            for(Purchase p: cart.getPurchases()){
                OrderItemEntity ooo = new OrderItemEntity();
                ooo.setOrderId(orderId);
                ooo.setProductId(p.getProductId());
                ooo.setName(p.getName());
                ooo.setQuantity(p.getQuantity());
                ooo.setPrice(p.getPrice());
                orefl.create(ooo);
            }
            
            //retreive the user's email address
            UserEntity ue = new UserEntity();
            ue = uefl.find(customer);
            String recipient = ue.getEmail();

            // Subject
            String subject = "Purchase Confirmation - Order Number: " + orderId;
        
            // Text
            String text = "Dear " + customer + ",\n\n"
                + "Thank you for your purchase at Innovation Lighting Store.\n\n"
                + "Please make the payment within 7 working days. Your purchase will be delivered upon recipt of payment.\n\n"
                + "Please visit our online store at http://innvolight.ddns.net:8080/InnovationLightingStore-war/\n\n"
                + "Yours faithfully,\n\n"
                + "Innovation Lighting Store";
        
            // send email to confirm purchase
            SendEmailViaGmail se = new SendEmailViaGmail();
            se.sendEmail(from, recipient, username, password, subject, text);

            //after writing the order to the database, clear the shopping cart
            cart.clearShoppingCart();
            response.sendRedirect(contextPath + "/paymentconfirmation.jsp");
            
        }else if(mas != null){
            
            int amount = Math.round(cart.getTotalAmount()) * 100 / 8;
            String reference = String.valueOf(orderId);
            
            ChargeMasterCard cmc = new ChargeMasterCard();
            cmc.chargeCard(amount, usd, description, reference, token);
            if(cmc.isApproved() == true){
                //create a order ID and record the date and current status 
                OrderEntity oe = new OrderEntity();
                oe.setUsername(customer);
                oe.setOrderDate(Date.valueOf(LocalDate.now()));
                oe.setStatus("being_processed");
                oe.setPaymentMethod("MasterCard");
                oe.setPayment("clear");
                oefl.create(oe);

                //after creating a order ID, retrieve the order ID from the database
                for(OrderEntity oee: oefl.findAll()){
                    if(oee.getUsername().equals(customer)){
                       orderId = oee.getId();
                    }
                }

                //create a order item ID for each purchased item and record related information 
                for(Purchase p: cart.getPurchases()){
                    OrderItemEntity ooo = new OrderItemEntity();
                    ooo.setOrderId(orderId);
                    ooo.setProductId(p.getProductId());
                    ooo.setName(p.getName());
                    ooo.setQuantity(p.getQuantity());
                    ooo.setPrice(p.getPrice());
                    orefl.create(ooo);
                }

                //retreive the user's email address
                UserEntity ue = new UserEntity();
                ue = uefl.find(customer);
                String recipient = ue.getEmail();

                // Subject
                String subject = "Purchase Confirmation - Order Number: " + orderId;

                // Text
                String text = "Dear " + customer + ",\n\n"
                    + "Thank you for your purchase at Innovation Lighting Store.\n\n"
                    + "Payment with Mastercard has been accepted. We are processing your order.\n\n"
                    + "Please visit our online store at http://innvolight.ddns.net:8080/InnovationLightingStore-war/\n\n"
                    + "Yours faithfully,\n\n"
                    + "Innovation Lighting Store";

                // send email to confirm purchase
                SendEmailViaGmail se = new SendEmailViaGmail();
                se.sendEmail(from, recipient, username, password, subject, text);

                //after writing the order to the database, clear the shopping cart
                cart.clearShoppingCart();
                response.sendRedirect(contextPath + "/paymentconfirmation.jsp");
            }else {
                response.sendRedirect(contextPath + "/card_payment_fail.jsp");
            }
            
        }else if (can != null){
            response.sendRedirect(contextPath + "/shoppingcart.jsp");
        }
            
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
