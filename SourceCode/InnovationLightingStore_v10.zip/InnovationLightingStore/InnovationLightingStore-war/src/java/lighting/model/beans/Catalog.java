/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lighting.model.beans;

import java.util.ArrayList;
import java.util.List;
import javax.ejb.EJB;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Named;
import lighting.entities.ProductEntity;
import lighting.entity.ejbs.ProductEntityFacadeLocal;

/**
 *
 * @author William
 */

@Named("catalog")
@ApplicationScoped
public class Catalog {
    
    @EJB
    private ProductEntityFacadeLocal pefl;
    private List<ProductEntity> products;

    public Catalog() {
        products = new ArrayList<>();
    }

    public List<ProductEntity> getProducts() {
        products = pefl.findAll();
        return products;
    }
    
    
    
}
