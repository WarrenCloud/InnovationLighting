/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lighting.model.beans;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.inject.Inject;
import javax.inject.Named;
import lighting.entities.OrderEntity;
import lighting.entity.ejbs.OrderEntityFacadeLocal;

/**
 *
 * @author William
 */
@Named("order")
@SessionScoped
public class OrderBean implements Serializable {
    
    @EJB
    private OrderEntityFacadeLocal oefl;
    
    @Inject
    private ShoppingCart cart;
    
    private LocalDate orderDate;
    
    private List<OrderEntity> orders;

    public OrderBean() {
        orders = new ArrayList();
    }

    public List<OrderEntity> getOrders() {
        orders = oefl.findAllByUsername(cart.getUsername());
        return orders;
    }

    public LocalDate getOrderDate() {
        return orderDate;
    }
    
    
    
}
