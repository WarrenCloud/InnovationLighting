/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lighting.model.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import lighting.models.Purchase;

@SessionScoped
@Named("shoppingcart")
public class ShoppingCart implements Serializable {
    
    //add each selected product into the list
    private List<Purchase> purchases;
    private String username;
    private String email;
    private float totalAmount;
    private boolean emptyCart;
    private int count;

    //Constructor to create a empty arraylist to store purchase and subtotal of each purchase
    public ShoppingCart() {
        purchases = new ArrayList<>();
    }

    //getter to return the arrylist of all purchases
    public List<Purchase> getPurchases() {
        return purchases;
    }

    //getter to return the username
    public String getUsername() {
        return username;
    }

    //setter to set the username
    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    
    //if user want to logout, make the variable username as null
    public void logout(){
        this.username = null;
    }
    
    //add the product into the list if the product is not in the cart
    public void addPurchase(Purchase pp){
        boolean found = false;
        for(Purchase p: purchases){
            if(p.getProductId() == pp.getProductId() ){
                found = true;
            }
        }
        if (!found){
            purchases.add(pp);
        }
    }
    
    //find the prodcut from the cart and then increase quantity by 1;
    public void increaseQuantity(int productId){
        for(Purchase p: purchases){
            if(p.getProductId() == productId){
                p.increaseQuantity();
            }
        }
    }
    
    /*
        find the prodcut from the cart and then idecrease quantity by 1.
        the quantity cannot be less than 1
    */
    public void decreaseQuantity(int productId){
        for(Purchase p: purchases){
            if(p.getProductId() == productId){
                if(p.getQuantity() > 1){
                    p.decreaseQuantity();
                }
            }
        }
    }
    
    /*
        find the prodcut from the cart and then calculate the total 
        amount of the selected product and update the cart
    */
    public void updateSubTotal(int prodcutId){
        for(Purchase p: purchases){
            if(p.getProductId() == prodcutId){
                p.setSubTotal();
            }
        }
    }


    //caluclate and return the total amount of all purchases
    public float getTotalAmount(){
        totalAmount = 0f;
        //totalAmount = "0.00";
        for(Purchase p: purchases){
            totalAmount += p.getPrice() * p.getQuantity();
            //totalAmount = String.format("%.2f", total);
        }
        return totalAmount;
    }
    
    //remove the purchase from the cart
    public void removePurchasedItem(int productId){
        int n = -1;
        int i = 0;
        for(Purchase p: purchases){
            if(p.getProductId() == productId) {
                n = i;
            }
            i++;
        }
        if(n != -1){
            purchases.remove(n);
        }    
    }

    //if the shopping cart is empty, return true
    public boolean isEmptyCart() {
        emptyCart = false;
        if(purchases.isEmpty()){
            emptyCart = true;
        }
        return emptyCart;
    }
    
    //remove all purchases in the shopping cart
    public void clearShoppingCart(){
        purchases.clear();
    }

    //get the total number of the purchase item in the shopping cart
    public int getCount() {
        count = purchases.size();
        return count;
    }
    
}
