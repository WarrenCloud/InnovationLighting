/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lighting.models;


public class Purchase {
    
private int productId;
private String Name;
private int quantity;
private float price;
private String imageLink;
private String subTotal;

    //constructor to create a record of the selected product
    public Purchase(int productId) {
        this.productId = productId;
        this.quantity = 1;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public int getQuantity() {
        return quantity;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public String getImageLink() {
        return imageLink;
    }

    public void setImageLink(String imageLink) {
        this.imageLink = imageLink;
    }
    
    //getter to return subtotal of each pruchase
    public String getSubTotal() {
        return subTotal;
    }

    //method to calculate ethe subtotal of each purchase
    public void setSubTotal() {
        float amount = this.getPrice() * this.getQuantity();
        this.subTotal = String.format("%.2f", amount);
        
    }
    //method to increase quantity
    public void increaseQuantity(){
        this.quantity++;
    }
    
    //method to decrease quantity;
    public void decreaseQuantity(){
        this.quantity--;
    }

}
