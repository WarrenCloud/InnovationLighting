/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lighting.models;

import com.simplify.payments.PaymentsApi;
import com.simplify.payments.PaymentsMap;
import com.simplify.payments.domain.Payment;
import com.simplify.payments.exception.ApiException;
import com.simplify.payments.exception.InvalidRequestException;




public class ChargeMasterCard {
    
    private boolean approved;

    public void chargeCard(int amount, String currency, String description, String reference, String token){
        
        PaymentsApi.PUBLIC_KEY = "sbpb_MzgwYWQ2YzAtOTM4Ni00ZmE3LWI5ZmQtYTU0MDRkOTZmYTY4";
        PaymentsApi.PRIVATE_KEY = "+NXXqpeEBRJjTkqfeYcBoOhiBOawEDcKJ36qs3QTAoR5YFFQL0ODSXAOkNtXTToq";

        try {
            Payment payment = Payment.create(new PaymentsMap()
                .set("amount", amount)
                .set("currency", currency)
                .set("description", description)
                .set("reference", reference)
                .set("token", token)
            );
            approved = false;
            if ("APPROVED".equals(payment.get("paymentStatus"))) {
                System.out.println("Payment approved");
                approved = true;
            }
        }catch (ApiException e) {
            System.out.println("Message:    " + e.getMessage());
            System.out.println("Reference:  " + e.getReference());
            System.out.println("Error code: " + e.getErrorCode());
            if (e instanceof InvalidRequestException) {
                InvalidRequestException e2 = (InvalidRequestException) e;
                if (e2.hasFieldErrors()) {
                    for (InvalidRequestException.FieldError fe : e2.getFieldErrors()) {
                        System.out.println(fe.getFieldName()
                               + ": '" + fe.getMessage()
                               + "' (" + fe.getErrorCode() + ")");
                    }
                }
            }
        }
    }

    public boolean isApproved() {
        return approved;
    }
    
    
    
    
}
