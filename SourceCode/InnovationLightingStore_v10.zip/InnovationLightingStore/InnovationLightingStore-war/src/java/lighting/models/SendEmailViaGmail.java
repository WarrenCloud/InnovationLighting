/*
    This is to send a email confirmation of the purchase to the customer.
    Send an Email via Gmail SMTP server using TLS connection.
 */
package lighting.models;

import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

/**
 *
 * @author William
 */
public class SendEmailViaGmail {
    
    public void sendEmail(String from, String recipient, String username,
            String password, String subject, String text){
        
      Properties props = new Properties();
      props.put("mail.smtp.auth", "true");
      props.put("mail.smtp.starttls.enable", "true");
      props.put("mail.smtp.host", "smtp.gmail.com");
      props.put("mail.smtp.port", "587");
      
      // Get the Session object.
      Session session = Session.getInstance(props,new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username, password);
            }
      });
      
      try {
         // Create a default MimeMessage object.
         Message message = new MimeMessage(session);

         // From: header field of the header.
         message.setFrom(new InternetAddress(from));

         // To: header field of the header.
         message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipient));

         // Subject: header field
         message.setSubject(subject);

         // Set the actual message
         message.setText(text);

         // Send message
         Transport.send(message);

        } catch (MessagingException e) {
            throw new RuntimeException(e);
        }
          
    }
    
}
