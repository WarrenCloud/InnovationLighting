function JS_GoToPage(type) {
	var page = "index.jsp";
	switch (type) {
		case "index": page = "index.jsp"; break;
		case "product": page = "catalog.jsp"; break;
		case "login": page = "login.jsp"; break;
		case "account": page = "account.jsp"; break;
		case "cart": page = "shoppingcart.jsp"; break;
		case "about": page = "about.jsp"; break;
		case "payment": page = "payment.html"; break;
	}
	
	location.href = page;
}
function JS_GenerateMenuBar(objectID, type) {
	var html = "";
	
	html += '<ul>';
	html += '<li id="li_index" onclick="JS_GoToPage(\'index\')"><span class="glyphicon glyphicon-home"></span> Home</li>';
	html += '<li id="li_product" onclick="JS_GoToPage(\'product\')"><span class="glyphicon glyphicon-list-alt"></span> Product List</li>';
	html += '<li id="li_cart" onclick="JS_GoToPage(\'cart\')"><span class="glyphicon glyphicon-shopping-cart"></span> Shopping Cart</li>';
	html += '<li id="li_account" onclick="JS_GoToPage(\'account\')"><span class="glyphicon glyphicon-user"></span> My Account</li>';
        html += '<li id="li_about" onclick="JS_GoToPage(\'about\')"><span class="glyphicon glyphicon-sunglasses"></span> About Us</li>';
	html += '<li id="li_cart" onclick="JS_ClickLogoutButton(\'btn_Logout\')"><span class="glyphicon glyphicon-user"></span> Logout</li>';
	html += '</ul>';
	
	$("#" + objectID).html(html);
}

function JS_ClickLogoutButton(objectID) {
	$("#"+objectID).click();
}

function JS_Logout() {
	alert("Logout");
}