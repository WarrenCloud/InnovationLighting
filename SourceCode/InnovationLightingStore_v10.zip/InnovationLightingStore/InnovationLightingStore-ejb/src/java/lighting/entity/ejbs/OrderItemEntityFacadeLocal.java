/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lighting.entity.ejbs;

import java.util.List;
import javax.ejb.Local;
import lighting.entities.OrderItemEntity;

/**
 *
 * @author William
 */
@Local
public interface OrderItemEntityFacadeLocal {

    void create(OrderItemEntity orderItemEntity);

    void edit(OrderItemEntity orderItemEntity);

    void remove(OrderItemEntity orderItemEntity);

    OrderItemEntity find(Object id);

    List<OrderItemEntity> findAll();

    List<OrderItemEntity> findRange(int[] range);

    int count();
    
    List<OrderItemEntity> findAllByOrderId(int id);
    
}
