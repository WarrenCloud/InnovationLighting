/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lighting.entity.ejbs;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import lighting.entities.OrderEntity;

/**
 *
 * @author William
 */
@Stateless
public class OrderEntityFacade extends AbstractFacade<OrderEntity> implements OrderEntityFacadeLocal {

    @PersistenceContext(unitName = "InnovationLightingStore-ejbPU")
    private EntityManager em;
    
    private List<OrderEntity> orders;
    
    private Object order;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public OrderEntityFacade() {
        super(OrderEntity.class);
    }
    
    public List<OrderEntity> findAllByUsername(String username){
        orders = em.createQuery("SELECT o FROM OrderEntity o where o.username = :username").setParameter("username", username).getResultList();
        return orders;   
    }
    
}
