/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lighting.entity.ejbs;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import lighting.entities.UserEntity;

/**
 *
 * @author William
 */
@Stateless
public class UserEntityFacade extends AbstractFacade<UserEntity> implements UserEntityFacadeLocal {

    @PersistenceContext(unitName = "InnovationLightingStore-ejbPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public UserEntityFacade() {
        super(UserEntity.class);
    }
    
}
