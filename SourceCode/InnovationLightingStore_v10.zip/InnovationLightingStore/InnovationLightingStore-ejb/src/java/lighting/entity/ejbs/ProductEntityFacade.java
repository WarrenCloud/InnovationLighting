/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lighting.entity.ejbs;

import javax.ejb.Stateless;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import lighting.entities.ProductEntity;

/**
 *
 * @author William Tai
 */
@Named("catalogue")
@Stateless
public class ProductEntityFacade extends AbstractFacade<ProductEntity> implements ProductEntityFacadeLocal {

    @PersistenceContext(unitName = "InnovationLightingStore-ejbPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public ProductEntityFacade() {
        super(ProductEntity.class);
    }
    
}
