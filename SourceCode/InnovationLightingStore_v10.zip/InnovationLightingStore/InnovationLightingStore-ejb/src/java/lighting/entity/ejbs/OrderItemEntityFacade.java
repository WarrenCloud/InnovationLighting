/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lighting.entity.ejbs;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import lighting.entities.OrderItemEntity;

/**
 *
 * @author William
 */
@Stateless
public class OrderItemEntityFacade extends AbstractFacade<OrderItemEntity> implements OrderItemEntityFacadeLocal {

    @PersistenceContext(unitName = "InnovationLightingStore-ejbPU")
    private EntityManager em;
    
    private List<OrderItemEntity> oie;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public OrderItemEntityFacade() {
        super(OrderItemEntity.class);
    }
    
    public List<OrderItemEntity> findAllByOrderId(int id){
        oie = em.createQuery("SELECT o FROM OrderItemEntity o WHERE o.orderId = ?1").setParameter(1, id).getResultList();
        return oie;
    }
    
}
