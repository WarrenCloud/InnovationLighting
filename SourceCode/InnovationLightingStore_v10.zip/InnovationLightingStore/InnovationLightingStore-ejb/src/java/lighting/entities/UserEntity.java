/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lighting.entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import org.hibernate.validator.constraints.NotBlank;

/**
 *
 * @author William
 */
@Entity
@Table(name = "LIGHTING_CUSTOMER")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "UserEntity.findAll", query = "SELECT a FROM UserEntity a")
    , @NamedQuery(name = "UserEntity.findByUsername", query = "SELECT a FROM UserEntity a WHERE a.username = :username")
    , @NamedQuery(name = "UserEntity.findByPassword", query = "SELECT a FROM UserEntity a WHERE a.password = :password")})
public class UserEntity implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @NotBlank
    @Size(min = 4, max = 255)
    @Column(name = "USERNAME")
    private String username;
    
    @NotNull
    @NotBlank
    @Size(min = 4, max = 255)
    @Column(name = "PASSWORD")
    private String password;
    
    
    @NotNull
    @NotBlank
    @Size(max = 255)
    @Column(name = "EMAIL")
    private String email;

    public UserEntity() {
    }

    public UserEntity(String username) {
        this.username = username;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (username != null ? username.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof UserEntity)) {
            return false;
        }
        UserEntity other = (UserEntity) object;
        if ((this.username == null && other.username != null) || (this.username != null && !this.username.equals(other.username))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "lighting.entities.UserEntity[ username=" + username + " ]";
    }
    
}
