/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lighting.ejbs;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.ejb.LocalBean;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import lighting.entities.UserEntity;
import lighting.entity.ejbs.UserEntityFacadeLocal;
import org.hibernate.validator.constraints.NotBlank;

/**
 *
 * @author William
 */
@Stateless
@LocalBean
public class UserAuthentication {

    @EJB
    private UserEntityFacadeLocal uefl;
    
    @NotNull
    @NotBlank
    @Size(min=4, max=50)
    private String newpassword;
    
    @NotNull
    @NotBlank
    @Size(min=4, max=50)
    private String reconfirm;
    private boolean passwordVerified;
    private boolean usernameExist;

    public String getNewpasword() {
        return newpassword;
    }

    public void setNewpasword(String newpassword) {
        this.newpassword = newpassword;
    }

    public String getReconfirm() {
        return reconfirm;
    }

    public void setReconfirm(String reconfirm) {
        this.reconfirm = reconfirm;
    }

    //to verify the password entered by the user
    public boolean isPasswordVerified(String username, String password) {
        passwordVerified = false;
        UserEntity ue = uefl.find(username);
        if(ue.getPassword().equals(password)){
            passwordVerified = true;
        }
        return passwordVerified;
    }
    
    //check if the username is already exist
    public boolean isUsernameExist(String username) {
        usernameExist = false;
        if (uefl.find(username) != null){
            usernameExist = true;
        }
        return usernameExist;
    }
 
    
}
